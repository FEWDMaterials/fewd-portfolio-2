/* CURRENTLY IN: javascript/main.js */
(function() {	// protect the lemmings!
	if ( $('body.view-mode').length ) {
		$('.line-numbers-rows>span.active').popover({trigger:'hover'})
		return false;
	}
	function getQueryVariable(variable) {
	    var query = window.location.search.substring(1);
	    var vars = query.split('&');
	    for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split('=');
		if (decodeURIComponent(pair[0]) == variable) {
		    return decodeURIComponent(pair[1]);
		}
	    }
	    console.log('Query variable %s not found', variable);
	}
	// if arg, prefill the input field
	if ( !!getQueryVariable('url') ) {
		$('#inputURL').val( getQueryVariable('url') );
	}
	if ( !!getQueryVariable('ftp') ) {
		var currVarURL = getQueryVariable('ftp');
		if (currVarURL.indexOf( 'ftp://ftp.taqquikarim.com/' ) !== -1 ) {
			var bits = currVarURL.split( 'ftp://ftp.taqquikarim.com/' );
			$('#inputURL').val( 'http://taqquikarim.com/studio/' + bits[1] );
		}
		else {
			$('#inputURL').val( currVarURL );
		}
	}
	var loadZip = function( formSel ){
		this.form = $( formSel );	
		this.init();
	}
	loadZip.prototype = {
		init: function() {
			var self = this;

			// set up click handler
			self.form.on(
				'submit'
				, self.onFormSubmit()
			);
		}
		, onFormSubmit: function() {
			var self = this;

			function processData( data ) {
				self.form.parent().remove();
				data = $.parseJSON( data );
				console.log( data );

				var cont = $( '#main-container' );
				var struct = [];
				var template = $( '#code-items' ).html();
				for( var file in data ) {
					var curr = data[ file ];
					struct.push( file );
					if ( curr == "" ) continue;
					var fileAr = file.split( '.' );
					var ext = fileAr[ 1 ];
					console.log( ext );
					if ( ext == 'html' ) ext = 'markup';
					if ( ext == 'js' ) ext = "javascript";
					if ( ext == 'github' ) ext = 'markup';
					var lclass = 'language-'+ext;
					console.log( lclass );
					
					var pre = $( '<pre/>' );
					pre.addClass( 'line-numbers' );
					var code = $('<code/>' );
					code.addClass( lclass );
					code.text( curr );
					pre.append( code );
					cont.append( '<h2><button type="button" class="btn btn-default btn-xs">TITLE</button><span style="margin-left: 15px;">'+ file +'</span></h2>').append( pre );
				}
				Prism.highlightAll();
				cont.append('<button type="button" class="btn btn-default btn-zip">Generate Zip</button>');
				cont.on(
					'click'
					, '.btn-zip'
					, function( e ) {
						e.preventDefault();
						runZipStuff();
					}
				);
				cont.on(
					'click'
					, '.line-numbers-rows>span'
					, function( e ) {
						e.preventDefault();
						var pos = $( this ).offset();
						console.log( pos );
						var x = pos.top;
						var y = pos.left;
						var rowIndex = $( this ).index('.line-numbers-rows>span');

						if ( $( this ).hasClass( 'active' ) ) {
							var val = $( this ).attr( 'data-content' );
						} else {
							var val = "";
						}
						cont.append(
							_.template(
								template
								, {
									x: pos.top
									, y: pos.left
									, myWidth: $( this ).width()
									, contWidth: cont.width()
									, myKey: rowIndex
									, val: val
								}
							)
						);
						$( this ).addClass( 'active' );
					}
				);

				cont.on(
					'click'
					, '.btn-save'
					, function(e) {
						e.preventDefault();

						var key = $( this ).parent().attr( 'data-key' );
						var span = $( $( '.line-numbers-rows>span' )[ parseInt( key ) ] );
						span.attr('data-content', $( this ).parent().find('textarea').val() );

						$( this ).parent().fadeOut( function() {
							$( this ).remove();	
						});

						span
							.attr('data-toggle', 'popover')
							.attr('data-placement', 'right')
							.attr( 'data-container', 'body' )
							.attr( 'data-html', 'true' );
						span.popover(
							{
								trigger: 'hover'
							}
						);
					}
				);

				cont.on(
					'click'
					, '.btn-cancel'
					, function(e) {
						e.preventDefault();

						var key = $( this ).parent().attr( 'data-key' );
						var span = $( $( '.line-numbers-rows>span' )[ parseInt( key ) ] );
						span
							.removeAttr( 'data-content' )
							.removeAttr( 'data-placement' )
							.removeAttr( 'data-container' )
							.removeAttr( 'data-html' );
						span.removeClass( 'active' );
						span.popover( 'destroy' );

						$( this ).parent().fadeOut( function() {
							$( this ).remove();	
						});
					}
				);
			}
			return function( e ) {
				e.preventDefault();
				
				var inputUrl = $( '#inputURL' );
				if ( 
					inputUrl.val().indexOf( '.html' ) != -1
					|| inputUrl.val().indexOf( '.css' ) != -1
					|| inputUrl.val().indexOf( '.js' ) != -1 
				) {
					alert( 'Too specific! Please supply parent directory! No .html, .css, .js files allowed. \n\n\n So if you\'re inputting something like:\n\t "http://studio.generalassemb.ly/FEWD31/Andrew_Lee/Cookie_recipe/index.html",\n\n please consider inputting something more like: \n\t "http://studio.generalassemb.ly/FEWD31/Andrew_Lee/Cookie_recipe/"' );
					return false;
				}

				ga(
					'send'
					, 'event'
					, 'gradr_hw_graded'
					, 'click'
					, $( '#inputURL' ).val()
				);

				$.post(
					"php/api/WGET/"
					, {
						url: $( '#inputURL' ).val()
						, pw: $( '#inputPassword' ).val()
					}
					, processData
				);
			}
		}
	}

	var lZ = new loadZip( '#urlForm' );

	// create zip here
	function runZipStuff() {
		var HTML = $( 'html' ).clone();
		HTML.find( 'body' ).addClass( 'view-mode' );
		var scripts = HTML.find( 'script' );
		scripts.each(function( idx, el ) {
			var src = $( el ).attr( 'src' );
			if ( typeof src == "undefined" ) return true;
			if ( src.indexOf( 'prism.js' ) != -1 ) return true;
			src = src.replace( /javascript\//, '' );
			$( el ).attr( 'src', src );
		});
		var links = HTML.find( 'link' );
		links.each(function( idx, el ) {
			var href = $( el ).attr( 'href' );
			if ( typeof href == "undefined" ) return true;
			href = href.replace( /styles\//, '' );
			$( el ).attr( 'href', href );
		});
		HTML.find( '.btn-zip' ).remove();
		var html = '<!doctype html><html>'+HTML.html()+'</html>';

		var fileBlob = [];
		fileBlob[ 0 ] = {
			blob: new Blob([ html ], {
		  		type : "text/html"
			})
			, name: 'index.html'
		};
		$.getJSON( 
			'php/api/GET/'
			, function( data ) {
				console.log( data );
				var iter = 1;
				for ( var items in data ) {
					var curr = data[ items ];
					var ar = items.split('/');
					var last = ar[ ar.length - 1 ];
					var lastAr = last.split( '.' );
					if ( lastAr[1] == 'js' ) {
						var type = 'javascript';
					} else {
						var type = "css";
					}
					fileBlob[ iter ] = {
						blob: new Blob([ curr ], {
							type: "text/"+type
						})
						, name: last
					};
					iter++;
				}
				makeZip( fileBlob );
				$( '#shim' ).fadeIn('fast');
			}
		);
	}

	function makeZip( fileBlob ) {
		zip.createWriter(new zip.BlobWriter("application/zip"), function(zipWriter) {
			var numFiles = Object.keys( fileBlob ).length;
	    		var oncompl = function(){ 
				zipWriter.close( function( zippedBlob ) {
					$( '#shim' ).fadeOut('fast');
					$('#main-container').append( '<a class="btn btn-primary btn-default" href="'+URL.createObjectURL(zippedBlob)+'">Download ZIP</a>' );
				});
	    		};

	    		var iter = 0;
	    		nextFile();
		    	function nextFile() {

				zipWriter.add(
					fileBlob[ iter ].name
					, new zip.BlobReader(fileBlob[ iter ].blob)
					, function() {
						iter++;
						console.log( iter, numFiles, iter/numFiles );
						$( '#shim .zip-prog .progress-bar' ).css(
							{ width: 100*(iter/numFiles)+'%' }
						);
						if ( iter == numFiles ) { oncompl(); } 
						else { nextFile(); }
					}
				);
		   	}
	  	});	
	} // makeZip
})();
